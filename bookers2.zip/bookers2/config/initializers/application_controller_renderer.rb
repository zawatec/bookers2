# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '24d39acc5921f35e9737f596414b1df552277457c38a244d554e7c01b4621d0ace608c22398061c1228e826120c73f4f5a6d863374cd669901f63eeed94b0c67'