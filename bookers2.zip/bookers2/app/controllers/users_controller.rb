class UsersController < ApplicationController
  
  
  before_action :user_check, only:[:edit, :update]
  
  def user_check
   return if User.find(params[:id]) == current_user # もし入力した数値のidユーザーとログイン中のユーザが一緒ならこのメソッドを抜ける
   redirect_to user_path(current_user)
  end
  
  def show
    @user = User.find(params[:id])
    @book = Book.new
    @my_books = @user.books.page(params[:page]).reverse_order
  end

  def create
    @book = Book.new(book_params)
    @book.user_id = current_user.id
    if @book.save
      flash[:notice] = "You have created book successfully."
      redirect_to book_path(@book.id)
    else
      @books = Book.all
      render :index
    end
  end

  def edit
    @user = User.find(params[:id])
  end

  def update
    @user = User.find(params[:id])
    if @user.update(user_params)
      flash[:notice] = "You have updated user successfully."
      redirect_to user_path
    else
      @users = User.all
      render :edit
    end

  end

  def index
    @users = User.all #Userモデルからデータを取得
    @book = Book.new
  end


  def destroy
  end

  private

  def user_params
    params.require(:user).permit(:name, :introduction, :profile_image)
  end

end



