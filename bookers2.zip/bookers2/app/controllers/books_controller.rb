class BooksController < ApplicationController
  
  before_action :user_check, only:[:edit, :update]
 
  def user_check
   return if Book.find(params[:id]).user.id == current_user.id # もし入力した数値のidユーザーとログイン中のユーザが一緒ならこのメソッドを抜ける
   redirect_to books_path
  end
  
  
  def create
    @book = Book.new(book_params)
    @book.user_id = current_user.id
    if @book.save
      flash[:notice] = "You have created book successfully."
      redirect_to book_path(@book.id)
    else
      @books = Book.all
      render :index
    end
  end

  def index
    @users = User.all #Userモデルからデータを取得
    @books = Book.all #Bookモデルからデータを取得
    @book = Book.new
    # @user = User.find(params[:id])
  end

  def show
    @book = Book.find(params[:id])
  end

  def edit
    @book = Book.find(params[:id])
    
    #編集対象がカレントユーザーのみ
  end

  def update
    @book = Book.find(params[:id])
    if @book.update(book_params)
      flash[:notice] = "You have updated book successfully."      
      redirect_to book_path
    else
      @books = Book.all
      render :index
    end
  end

  def destroy
   @book = Book.find(params[:id])
   @book.destroy
   redirect_to books_path
    # flash[:notice] = "Book was successfully destroyed."
  end

  private

  def book_params
    params.require(:book).permit(:title, :body )
  end

end
